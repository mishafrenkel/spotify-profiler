import styled from 'styled-components/macro';

const Header = styled.header`
  margin: 0;
`;

export default Header;
